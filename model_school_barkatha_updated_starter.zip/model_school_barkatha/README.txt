MODEL SCHOOL BARKATHA WEBSITE — UPDATED STARTER
================================================

Files
-----
index.html   Main mobile-friendly website.
README.txt   This beginner-friendly guide.

IMPORTANT PROJECT STATUS
------------------------
This is a front-end starter/template. It includes Home/About, notices, Classes 6–10,
books/PDF area, homework, timetable, exam corner, teacher directory, gallery,
feedback/chat demos, and an Owner/Admin system design preview.

The website does NOT yet have:
- real Owner/Admin authentication or secure permissions
- shared online content editing/database
- live chat shared between different visitors
- private complaints delivered to school staff
- real student accounts, notifications or backups

Do not put passwords, student personal information, or real complaints into the demo.
Before publishing official school information/photos, get permission from the school.
GitHub Pages is static hosting and does not supply a backend/database.

HOW TO CHECK ON YOUR PHONE
--------------------------
1. Download this ZIP and extract it in your phone's Files/File Manager app.
2. Open index.html in Chrome if your file manager offers that option.
   If local opening does not work, upload it to GitHub Pages using the steps below.

HOW TO PUBLISH FOR FREE WITH GITHUB PAGES (ANDROID)
---------------------------------------------------
1. Open Chrome and go to https://github.com, then sign in or create an account.
2. Tap + (or the create menu) and choose New repository.
3. Repository name: model-school-barkatha
4. Choose Public only if you are comfortable making the website files public.
5. Create repository.
6. Open the repository and choose Add file -> Upload files.
   If the mobile interface hides this, open Chrome's three-dot menu and choose Desktop site.
7. Upload index.html itself to the repository root (top level). Do not upload only the ZIP.
8. Scroll down and tap Commit changes.
9. Open Settings -> Pages.
10. Under Build and deployment, choose Deploy from a branch.
11. Select branch main and folder /(root), then Save.
12. Wait for publishing. Open Settings -> Pages and look for the Visit site link.
13. The address normally looks like:
    https://YOUR-GITHUB-USERNAME.github.io/model-school-barkatha/
    Replace YOUR-GITHUB-USERNAME with your actual GitHub username.

HOW TO UPDATE THE WEBSITE LATER
-------------------------------
For basic text/code edits:
1. Open the repository on GitHub.
2. Open index.html and choose the pencil/Edit option.
3. Make a change, then Commit changes.
4. Wait for the published page to update; refresh Chrome.

For photos or PDFs:
1. Upload the image/PDF file to the repository using Add file -> Upload files.
2. The HTML must link to the exact uploaded filename/path. If the HTML doesn't already
   contain an upload slot/link, the code needs editing to display it.
3. Commit the changes and wait for publishing.

Google Search versus Chrome:
- The GitHub Pages URL can be opened in Chrome as soon as publishing succeeds.
- Google Search indexing is separate, can take time, and is not guaranteed.
- A site does not automatically rank first for the school name.

OWNER / ADMIN SYSTEM — NEXT PHASE
---------------------------------
The page currently describes the planned roles but does not implement a secure login.
To support a real Owner who can invite multiple Admins with different permissions,
publish shared notices/photos/PDFs without editing code, and support real chat/private
complaints, the next phase needs a trusted backend/database, secure authentication,
server-side permission checks, storage rules, backups and moderation. Do not treat a
front-end-only login or browser local storage as secure.

Suggested roles:
- Owner: manage admins, roles, site settings and all approved content.
- Admin: only assigned permissions (e.g. notices, homework, materials).
- Visitor: view public content only.

For a school project, get a teacher/school administrator's approval before publishing
official school details or enabling student accounts/chat/complaints.
